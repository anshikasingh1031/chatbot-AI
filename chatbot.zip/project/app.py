from flask import Flask, request, jsonify, render_template
import requests

app = Flask(__name__)

# Use your actual OpenRouter API Key
OPENROUTER_API_KEY = "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"

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/ask", methods=["POST"])
def ask():
    user_input = request.json["question"]

    headers = {
        "Authorization": f"Bearer {OPENROUTER_API_KEY}",
        "Content-Type": "application/json"
    }

    data = {
        "model": "openai/gpt-3.5-turbo",  # Change to another model if needed
        "messages": [
            {"role": "system", "content": "You are a home improvement guidance assistant. Only provide helpful and professional advice related to home renovation, interior design, repairs, or smart home upgrades."},
            {"role": "user", "content": user_input}
        ]
    }

    try:
        response = requests.post("https://openrouter.ai/api/v1/chat/completions", headers=headers, json=data)
        response_data = response.json()

        if "choices" in response_data and response_data["choices"]:
            answer = response_data["choices"][0]["message"]["content"]
        else:
            answer = "⚠️ Unexpected response from AI."

    except Exception as e:
        answer = f"⚠️ Error: {str(e)}"

    return jsonify({"answer": answer})

if __name__ == "__main__":
    app.run(debug=True)
