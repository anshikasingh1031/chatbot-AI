async function sendQuestion() {
    const input = document.getElementById("question");
    const question = input.value.trim();
    if (!question) return;
  
    const chatBox = document.getElementById("chat-box");
    chatBox.innerHTML += `<div class="message user"><strong>You:</strong> ${question}</div>`;
  
    const response = await fetch("/ask", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ question })
    });
  
    const data = await response.json();
    chatBox.innerHTML += `<div class="message bot"><strong>Bot:</strong> ${data.answer}</div>`;
  
    input.value = "";
    chatBox.scrollTop = chatBox.scrollHeight;
  }
  